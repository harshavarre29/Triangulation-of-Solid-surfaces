

interface PointInterface {
	
   float getX();
   float getY();
   float getZ();

	//[x,y,z]  3 dimensions first is x second y and third is z.
	// This order should be followed

    float [] getXYZcoordinate();

}

